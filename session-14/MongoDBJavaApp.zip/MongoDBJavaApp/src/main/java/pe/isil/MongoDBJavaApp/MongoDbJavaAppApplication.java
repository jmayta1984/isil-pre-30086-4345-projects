package pe.isil.MongoDBJavaApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MongoDbJavaAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(MongoDbJavaAppApplication.class, args);
	}

}
